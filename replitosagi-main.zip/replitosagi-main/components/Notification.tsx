import React, { useEffect, useState } from 'react';
import { useNotifications } from './AppContext';
import type { Notification as NotificationData } from '../types';

const NOTIFICATION_TIMEOUT = 5000;

const Notification: React.FC<{ notification: NotificationData, onDismiss: (id: number) => void }> = ({ notification, onDismiss }) => {
    const [exiting, setExiting] = useState(false);

    useEffect(() => {
        const timer = setTimeout(() => {
            setExiting(true);
            setTimeout(() => onDismiss(notification.id), 300);
        }, NOTIFICATION_TIMEOUT);

        return () => clearTimeout(timer);
    }, [notification.id, onDismiss]);

    const handleDismiss = () => {
      setExiting(true);
      setTimeout(() => onDismiss(notification.id), 300);
    }

    const typeClasses = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        info: 'bg-blue-500',
        warning: 'bg-amber-500'
    };

    return (
        <div 
            className={`
                relative flex items-center p-4 mb-3 text-white rounded-lg shadow-lg w-full max-w-sm
                transition-all duration-300 ease-in-out
                ${typeClasses[notification.type]}
                ${exiting ? 'opacity-0 transform translate-x-full' : 'opacity-100 transform translate-x-0'}
            `}
            role="alert"
        >
            <div className="flex-grow">{notification.message}</div>
            <button onClick={handleDismiss} className="ml-4 p-1 rounded-full hover:bg-white/20 transition-colors focus:outline-none">&times;</button>
        </div>
    );
};

export const NotificationTray: React.FC = () => {
    const { notifications, removeNotification } = useNotifications();

    return (
        <div className="fixed top-5 right-5 z-50 w-full max-w-sm">
            {notifications.map(n => (
                <Notification key={n.id} notification={n} onDismiss={removeNotification} />
            ))}
        </div>
    );
};
