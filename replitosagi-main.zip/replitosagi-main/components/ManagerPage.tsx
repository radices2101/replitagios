import React, { useState, useMemo, useEffect } from 'react';
import type { Wallet, Transfer, WalletType, TransferType, TransferStatus, Currency, SecurityEvent } from '../types';
import { useRealtimeMetrics } from '../hooks/useRealtimeMetrics';
import { useData, useNotifications } from './AppContext';
import { NotificationTray } from './Notification';


type TabName = 'dashboard' | 'wallet' | 'transfer' | 'security' | 'blockchain' | 'network' | 'analytics';

const TABS: { id: TabName; label: string; icon: string; }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'wallet', label: 'Wallet', icon: '💰' },
    { id: 'transfer', label: 'Transfer', icon: '💸' },
    { id: 'security', label: 'Security', icon: '🛡️' },
    { id: 'blockchain', label: 'Blockchain', icon: '⛓️' },
    { id: 'network', label: 'Network', icon: '🌐' },
    { id: 'analytics', label: 'Analytics', icon: '📈' },
];

const ManagerPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<TabName>('dashboard');
    const { 
        wallets, 
        setWallets, 
        transferHistory, 
        addTransfer, 
        addWallet, 
        toggleWalletVisibility, 
        prefill, 
        setPrefill 
    } = useData();
    const { addNotification } = useNotifications();
    
    const [isCreatingWallet, setIsCreatingWallet] = useState(false);
    
    const realtimeData = useRealtimeMetrics();

    const totalPortfolioValue = useMemo(() => wallets.reduce((sum, w) => sum + w.usdValue, 0), [wallets]);

    const handleGenerateWallet = (name: string, type: WalletType) => {
        addWallet(name, type);
        setIsCreatingWallet(false);
        addNotification('✅ Wallet created successfully! Please backup your private key securely.', 'success');
    };

    const handleTogglePrivateKey = (id: number) => {
        toggleWalletVisibility(id);
    };

    const handleProcessTransfer = (fromAddress: string, to: string, amountStr: string, currency: Currency, memo: string, type: TransferType) => {
        const success = addTransfer(fromAddress, to, amountStr, currency, memo, type);
        if (typeof success === 'string') {
            addNotification(`❌ ${success}`, 'error');
            return false;
        }
        addNotification('✅ Transfer initiated successfully!', 'success');
        return true;
    };

    const copyToClipboard = (text: string) => {
      navigator.clipboard.writeText(text);
      addNotification('✅ Copied to clipboard!', 'info');
    };
    
    const initiateTransferFromWallet = (address: string, currency: WalletType) => {
      setActiveTab('transfer');
      setPrefill({ address, currency });
    };

    return (
        <div className="bg-gradient-to-br from-slate-50 to-blue-100 text-slate-800 min-h-screen p-2 sm:p-5">
            <NotificationTray />
            <div className="container mx-auto">
                <Header />
                <div className="flex flex-wrap gap-2.5 mb-7 bg-white p-4 rounded-xl shadow-lg">
                    {TABS.map(tab => (
                        <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                            className={`py-3 px-6 border-none rounded-lg cursor-pointer font-semibold transition-all duration-300 text-slate-800 flex-grow
                                ${activeTab === tab.id
                                    ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg transform -translate-y-0.5'
                                    : 'bg-slate-200 hover:bg-slate-300 hover:-translate-y-0.5'
                                }`}
                        >
                           {tab.icon} {tab.label}
                        </button>
                    ))}
                </div>

                {activeTab === 'dashboard' && <DashboardSection metrics={realtimeData} />}
                {activeTab === 'wallet' && <WalletSection wallets={wallets} totalValue={totalPortfolioValue} isCreating={isCreatingWallet} setIsCreating={setIsCreatingWallet} onGenerateWallet={handleGenerateWallet} onTogglePrivateKey={handleTogglePrivateKey} onCopyToClipboard={copyToClipboard} onInitiateTransfer={initiateTransferFromWallet} />}
                {activeTab === 'transfer' && <TransferSection wallets={wallets} transferHistory={transferHistory} onProcessTransfer={handleProcessTransfer} onCopyToClipboard={copyToClipboard} prefillData={prefill} clearPrefill={() => setPrefill(null)}/>}
                {activeTab === 'security' && <SecuritySection />}
                {activeTab === 'blockchain' && <BlockchainSection />}
                {activeTab === 'network' && <NetworkSection metrics={realtimeData}/>}
                {activeTab === 'analytics' && <AnalyticsSection />}
            </div>
             <footer className="text-center mt-8 p-5 text-slate-500 text-sm">
                <p>Replitagios v9998776 • Production Ready • Blockchain Intelligence Platform</p>
                <p className="mt-1">Protected by AGI Security System • Multi-Chain Compatible</p>
            </footer>
        </div>
    );
};


const Header: React.FC = () => (
    <header className="bg-gradient-to-r from-blue-500 to-purple-500 text-white p-8 rounded-2xl mb-8 shadow-2xl shadow-blue-500/30">
        <h1 className="text-4xl font-bold mb-2">🚀 Replitagios Manager</h1>
        <p>Production Ready • AGI Protected • Multi-Chain Platform</p>
        <div className="flex justify-between items-center flex-wrap gap-2 mt-4 text-sm">
            <div className="flex flex-wrap gap-2">
                <span className="badge">🔒 9998776 Trillion Secure</span>
                <span className="badge">⚡ Real-time Monitoring</span>
                <span className="badge">🌐 Multi-Chain</span>
            </div>
            <div className="text-right">
                <div>© 2025 Ervin Remus Radosavlevici</div>
                <div className="text-xs">ervin210@icloud.com</div>
            </div>
        </div>
    </header>
);

const Card: React.FC<{ children: React.ReactNode; className?: string; title?: string }> = ({ children, className = '', title }) => (
    <div className={`bg-white rounded-xl p-6 mb-5 shadow-lg ${className}`}>
        {title && <h3 className="mb-5 text-blue-600 text-2xl font-bold">{title}</h3>}
        {children}
    </div>
);

const StatCard: React.FC<{ title: string; value: string; color: string; }> = ({ title, value, color }) => {
    const colorClasses = {
        green: 'bg-green-100 border-green-500 text-green-600',
        blue: 'bg-blue-100 border-blue-500 text-blue-600',
        amber: 'bg-amber-100 border-amber-500 text-amber-600',
        purple: 'bg-purple-100 border-purple-500 text-purple-600'
    }[color] || 'bg-gray-100 border-gray-500 text-gray-600';

    return (
        <div className={`p-5 rounded-lg border-2 ${colorClasses}`}>
            <h4 className="text-sm text-slate-500 mb-2">{title}</h4>
            <div className="text-3xl font-bold">{value}</div>
        </div>
    );
};

const DashboardSection: React.FC<{ metrics: ReturnType<typeof useRealtimeMetrics> }> = ({ metrics }) => (
    <div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-5">
            <StatCard title="Security Level" value="8888T AGI" color="green" />
            <StatCard title="Network Status" value="ONLINE" color="blue" />
            <StatCard title="Active Nodes" value={metrics.activeNodes.toString()} color="amber" />
            <StatCard title="Uptime" value="99.9%" color="purple" />
        </div>
        <Card title="Real-Time System Metrics">
            <MetricProgressBar label="CPU Usage" value={metrics.cpuUsage} unit="%" color="bg-blue-500" />
            <MetricProgressBar label="Memory Usage" value={metrics.memoryUsage} unit="%" color="bg-green-500" />
            <MetricProgressBar label="Network Latency" value={metrics.networkLatency} unit="ms" max={50} color="bg-purple-500" />
        </Card>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <Card title="Recent Transactions"><RecentTransactions /></Card>
            <Card title="System Alerts"><SystemAlerts /></Card>
        </div>
    </div>
);

const MetricProgressBar: React.FC<{ label: string; value: number; unit: string; max?: number; color: string }> = ({ label, value, unit, max = 100, color }) => (
    <div className="mb-4">
        <div className="flex justify-between mb-2 text-sm">
            <span>{label}</span>
            <span>{value.toFixed(label === 'Network Latency' ? 0 : 1)}{unit}</span>
        </div>
        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-500 ease-out ${color}`} style={{ width: `${(value / max) * 100}%` }}></div>
        </div>
    </div>
);

const RecentTransactions: React.FC = () => {
    const { transferHistory } = useData();
    const recentTransfers = transferHistory.slice(0, 4);

    return (
        <div>
            {recentTransfers.map((tx) => (
                <div key={tx.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg mb-2 last:mb-0">
                    <div>
                        <div className="font-mono text-sm font-semibold">{tx.txHash.slice(0,6)}...{tx.txHash.slice(-4)}</div>
                        <div className="text-xs text-slate-500">{tx.type} transfer - {tx.amount} {tx.currency}</div>
                    </div>
                    <div className="text-right">
                        <div className={`text-xs font-bold ${tx.status === 'completed' ? 'text-green-600' : tx.status === 'pending' ? 'text-amber-600' : 'text-red-600'}`}>{tx.status.toUpperCase()}</div>
                        <div className="text-xs text-slate-500">{new Date(tx.timestamp).toLocaleTimeString()}</div>
                    </div>
                </div>
            ))}
        </div>
    );
};

const SystemAlerts: React.FC = () => (
    <div>
        <div className="flex items-start gap-3 p-4 mb-3 bg-green-100 border-2 border-green-500 text-green-800 rounded-lg">
            <span className="text-2xl">✅</span>
            <div>
                <strong className="font-semibold">Security Scan Complete</strong>
                <div className="text-sm">No vulnerabilities detected</div>
            </div>
        </div>
        <div className="flex items-start gap-3 p-4 bg-blue-100 border-2 border-blue-500 text-blue-800 rounded-lg">
            <span className="text-2xl">⚡</span>
            <div>
                <strong className="font-semibold">Performance Optimized</strong>
                <div className="text-sm">System running at 95% efficiency</div>
            </div>
        </div>
    </div>
);

const WalletSection: React.FC<{ wallets: Wallet[], totalValue: number, isCreating: boolean, setIsCreating: (isCreating: boolean) => void, onGenerateWallet: (name: string, type: WalletType) => void, onTogglePrivateKey: (id: number) => void, onCopyToClipboard: (text: string) => void, onInitiateTransfer: (address: string, type: WalletType) => void }> = ({ wallets, totalValue, isCreating, setIsCreating, onGenerateWallet, onTogglePrivateKey, onCopyToClipboard, onInitiateTransfer }) => {
    
    const [newWalletName, setNewWalletName] = useState('');
    const [newWalletType, setNewWalletType] = useState<WalletType>('ETH');

    const handleCreate = () => {
        onGenerateWallet(newWalletName || 'New Wallet', newWalletType);
        setNewWalletName('');
    };

    return (
        <div>
            <Card className="bg-gradient-to-r from-purple-50 to-blue-50">
                <h4 className="text-slate-500 mb-2">Total Portfolio Value</h4>
                <div className="text-4xl font-bold text-purple-600">${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                <div className="mt-2 text-slate-600">{wallets.length} Wallets • <span className="text-green-600">↑ 12.4% (24h)</span></div>
            </Card>
            <button onClick={() => setIsCreating(!isCreating)} className="btn-primary w-full mb-5">
                {isCreating ? '➖ Cancel Creation' : '➕ Create New Wallet'}
            </button>
            {isCreating && (
                <Card title="Create New Wallet">
                    <label className="font-semibold">Wallet Name</label>
                    <input type="text" value={newWalletName} onChange={e => setNewWalletName(e.target.value)} placeholder="My New Wallet" className="input-field" />
                    <label className="font-semibold mt-4 block">Blockchain Type</label>
                    <select value={newWalletType} onChange={e => setNewWalletType(e.target.value as WalletType)} className="input-field">
                        <option value="ETH">Ethereum (ETH)</option>
                        <option value="BTC">Bitcoin (BTC)</option>
                        <option value="BSC">Binance Smart Chain (BSC)</option>
                        <option value="MATIC">Polygon (MATIC)</option>
                    </select>
                    <div className="flex gap-4 mt-5">
                        <button onClick={handleCreate} className="btn-success flex-1">Generate Wallet</button>
                        <button onClick={() => setIsCreating(false)} className="btn-secondary flex-1">Cancel</button>
                    </div>
                     <div className="flex items-start gap-3 p-4 mt-4 bg-amber-100 border-2 border-amber-500 text-amber-800 rounded-lg">
                        <span>⚠️</span>
                        <div><strong>Important:</strong> Backup your private key immediately. Never share it!</div>
                    </div>
                </Card>
            )}
             <div>{wallets.map(w => <WalletItem key={w.id} wallet={w} onTogglePrivateKey={onTogglePrivateKey} onCopyToClipboard={onCopyToClipboard} onInitiateTransfer={onInitiateTransfer}/>)}</div>
        </div>
    );
};

const WalletItem: React.FC<{wallet: Wallet, onTogglePrivateKey: (id: number) => void, onCopyToClipboard: (text: string) => void, onInitiateTransfer: (address: string, type: WalletType) => void}> = ({wallet, onTogglePrivateKey, onCopyToClipboard, onInitiateTransfer}) => (
    <div className="border-2 border-slate-200 rounded-xl p-5 mb-4 hover:border-blue-500 transition-colors">
        <div className="flex justify-between items-start mb-4">
            <div>
                <h4 className="font-bold text-lg mb-1">{wallet.name}</h4>
                <span className="text-xs text-slate-500">{wallet.type} Wallet</span>
            </div>
            <div className="text-right">
                <div className="text-xl font-bold text-blue-600">{wallet.balance.toFixed(4)} {wallet.type}</div>
                <div className="text-sm text-slate-500">${wallet.usdValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
            </div>
        </div>
        
        <div className="mt-4">
            <label className="text-xs text-slate-500">Address</label>
            <div className="code-box"><span>{wallet.address}</span><button className="btn-icon" onClick={() => onCopyToClipboard(wallet.address)}>📋</button></div>
        </div>
        <div className="mt-4">
            <label className="text-xs text-slate-500">Private Key</label>
            <div className="code-box">
                <span className="truncate">{wallet.visible ? wallet.privateKey : '••••••••••••••••••••••••••••••••••••••••••••••••••••••••'}</span>
                <div className="flex gap-1">
                    <button className="btn-icon" onClick={() => onTogglePrivateKey(wallet.id)}>{wallet.visible ? '👁️' : '👁️‍🗨️'}</button>
                    {wallet.visible && <button className="btn-icon" onClick={() => onCopyToClipboard(wallet.privateKey)}>📋</button>}
                </div>
            </div>
        </div>
        <div className="flex gap-2.5 mt-4">
            <button className="btn-success flex-1 text-sm">💾 Export</button>
            <button onClick={() => onInitiateTransfer(wallet.address, wallet.type)} className="btn-primary flex-1 text-sm">💸 Transfer</button>
        </div>
         <div className="mt-3 pt-3 border-t border-slate-200 text-xs text-slate-500">Created: {wallet.createdAt}</div>
    </div>
);

const TransferSection: React.FC<{wallets: Wallet[], transferHistory: Transfer[], onProcessTransfer: (...args: any[]) => boolean | void, onCopyToClipboard: (text: string) => void, prefillData: {address: string, currency: WalletType} | null, clearPrefill: () => void}> = ({wallets, transferHistory, onProcessTransfer, onCopyToClipboard, prefillData, clearPrefill}) => {
    const [transferType, setTransferType] = useState<TransferType>('crypto');
    const [from, setFrom] = useState('');
    const [to, setTo] = useState('');
    const [amount, setAmount] = useState('');
    const [currency, setCurrency] = useState<Currency>('ETH');
    const [memo, setMemo] = useState('');

    const { CURRENCY_RATES } = useData();
    const estimatedValue = (parseFloat(amount) || 0) * (CURRENCY_RATES[currency] || 0);

    const handleSubmit = () => {
        const success = onProcessTransfer(from, to, amount, currency, memo, transferType);
        if (success) {
            setFrom(''); setTo(''); setAmount(''); setMemo('');
        }
    };
    
    useEffect(() => {
      if (prefillData) {
        setFrom(prefillData.address);
        setCurrency(prefillData.currency);
        clearPrefill();
      }
    }, [prefillData, clearPrefill]);

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <Card title="New Transfer">
                <div className="grid grid-cols-2 gap-4 mb-4">
                    <button onClick={() => { setTransferType('crypto'); setCurrency('ETH'); }} className={`tab-button ${transferType === 'crypto' ? 'active' : ''}`}>Crypto</button>
                    <button onClick={() => { setTransferType('bank'); setCurrency('USD'); }} className={`tab-button ${transferType === 'bank' ? 'active' : ''}`}>Bank</button>
                </div>
                <label>From Wallet</label>
                <select value={from} onChange={e => setFrom(e.target.value)} className="input-field">
                    <option value="">Select Wallet</option>
                    {wallets.map(w => <option key={w.id} value={w.address}>{w.name} - {w.balance.toFixed(4)} {w.type}</option>)}
                </select>
                <label className="mt-4 block">Recipient Address</label>
                <input type="text" value={to} onChange={e => setTo(e.target.value)} placeholder={transferType === 'crypto' ? '0x...' : 'Bank Account...'} className="input-field" />
                <div className="grid grid-cols-2 gap-4 mt-4">
                    <div><label>Amount</label><input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" className="input-field"/></div>
                    <div><label>Currency</label>
                        <select value={currency} onChange={e => setCurrency(e.target.value as Currency)} className="input-field">
                            {transferType === 'crypto' 
                                ? ['ETH', 'BTC', 'BSC', 'MATIC'].map(c => <option key={c} value={c}>{c}</option>) 
                                : ['USD', 'EUR', 'GBP'].map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                </div>
                <label className="mt-4 block">Memo (Optional)</label>
                <input type="text" value={memo} onChange={e => setMemo(e.target.value)} placeholder="Add a note..." className="input-field"/>
                
                {amount && <div className="bg-blue-50 p-4 rounded-lg mt-4 flex justify-between items-center">
                    <span className="text-slate-600">Estimated Value:</span>
                    <span className="text-2xl font-bold text-blue-600">${estimatedValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                </div>}

                <button onClick={handleSubmit} className="btn-success w-full mt-5">💸 Process Transfer</button>
            </Card>
            <Card title="Transfer History">
              <div className="max-h-[600px] overflow-y-auto pr-2">
                {transferHistory.map(t => <TransferItem key={t.id} transfer={t} onCopyToClipboard={onCopyToClipboard}/>)}
              </div>
            </Card>
        </div>
    );
};

const TransferItem: React.FC<{transfer: Transfer, onCopyToClipboard: (text: string) => void}> = ({transfer, onCopyToClipboard}) => {
  const statusClasses: {[key in TransferStatus]: string} = {
    completed: 'bg-green-100 text-green-700',
    pending: 'bg-amber-100 text-amber-700',
    failed: 'bg-red-100 text-red-700',
  };
   const typeClasses: {[key in TransferType]: string} = {
    crypto: 'bg-blue-100 text-blue-700',
    bank: 'bg-emerald-100 text-emerald-700',
  };

  return (
    <div className="border-2 border-slate-200 rounded-xl p-4 mb-3">
        <div className="flex justify-between items-start mb-3">
            <div>
                <span className={`status-badge ${typeClasses[transfer.type]}`}>{transfer.type}</span>
                <span className={`status-badge ${statusClasses[transfer.status]}`}>{transfer.status}</span>
                <div className="text-xs text-slate-500 mt-1">{new Date(transfer.timestamp).toLocaleString()}</div>
            </div>
            <div className="text-right">
                <div className="text-lg font-bold">{transfer.amount} {transfer.currency}</div>
                <div className="text-sm text-slate-500">${transfer.usdValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
            </div>
        </div>
        <div className="text-sm">
            <div className="mb-2">
                <span className="text-slate-500">From:</span>
                <code className="code-badge ml-2">{transfer.from}</code>
            </div>
            <div className="pl-5 mb-2">→</div>
            <div>
                <span className="text-slate-500">To:</span>
                <code className="code-badge ml-2">{transfer.to}</code>
            </div>
            <div className="flex justify-between items-center pt-2 mt-2 border-t border-slate-200">
                <span className="text-slate-500 text-xs">TX Hash:</span>
                <div className="flex gap-2 items-center">
                    <code className="code-badge">{transfer.txHash}</code>
                    <button onClick={() => onCopyToClipboard(transfer.txHash)} className="btn-icon-sm">📋</button>
                </div>
            </div>
            {transfer.memo && <div className="pt-2 mt-2 border-t border-slate-200 text-slate-600"><span className="text-slate-500">Memo:</span> {transfer.memo}</div>}
        </div>
    </div>
  );
};

const SecuritySection: React.FC = () => {
    const { lockedEntities, securityLog, addLockedEntity } = useData();
    const [newEntity, setNewEntity] = useState('');

    const handleLockEntity = () => {
        if (newEntity.trim()) {
            addLockedEntity(newEntity.trim());
            setNewEntity('');
        }
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <Card title="Quantum Threat Management">
                <p className="mb-4 text-slate-600">Monitor and manage entities locked by the AGI security system. Add new threats to the Quantum Lock for immediate neutralization.</p>
                <div className="flex gap-2 mb-4">
                    <input 
                        type="text" 
                        value={newEntity}
                        onChange={e => setNewEntity(e.target.value)}
                        placeholder="e.g., unauthorized.node.xyz" 
                        className="input-field flex-grow !mt-0" 
                    />
                    <button onClick={handleLockEntity} className="btn-danger whitespace-nowrap">🔒 Lock Entity</button>
                </div>
                <h4 className="font-bold text-lg mb-2 text-slate-700">Locked Entities ({lockedEntities.length})</h4>
                <div className="bg-slate-800 text-slate-200 p-3 rounded-lg font-mono text-sm max-h-64 overflow-y-auto">
                    {lockedEntities.map(entity => <div key={entity} className="flex items-center gap-2 py-1"><span className="text-red-400">🚫</span>{entity}</div>)}
                </div>
            </Card>
            <Card title="Live Security Event Log">
                <div className="bg-black text-white p-4 font-mono text-xs rounded-lg h-[450px] overflow-y-auto flex flex-col-reverse">
                    <div>
                        {securityLog.map(log => {
                            const statusColor = log.status === 'success' ? 'text-green-400' : log.status === 'failure' ? 'text-red-400' : 'text-blue-400';
                            return (
                                <div key={log.id} className="mb-2">
                                    <span className="text-gray-500">{log.timestamp} </span>
                                    <span className={statusColor}>[{log.event}]</span>
                                    <span className="text-gray-300">: {log.target}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </Card>
        </div>
    );
};

const BlockchainSection: React.FC = () => (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <Card className="text-center"><h4 className="text-purple-600">Ethereum</h4><div className="text-3xl font-bold">47 Nodes</div><div className="text-sm text-slate-500">Online & Synced</div></Card>
        <Card className="text-center"><h4 className="text-amber-600">Bitcoin</h4><div className="text-3xl font-bold">32 Nodes</div><div className="text-sm text-slate-500">Online & Synced</div></Card>
        <Card className="text-center"><h4 className="text-blue-600">Polygon</h4><div className="text-3xl font-bold">28 Nodes</div><div className="text-sm text-slate-500">Online & Synced</div></Card>
      </div>
      <Card title="Blockchain Operations">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-5 bg-blue-100 rounded-lg"><div className="text-2xl font-bold text-blue-600">12,453</div><div className="text-sm text-slate-500">Total Transactions</div></div>
          <div className="text-center p-5 bg-green-100 rounded-lg"><div className="text-2xl font-bold text-green-600">156</div><div className="text-sm text-slate-500">Smart Contracts</div></div>
          <div className="text-center p-5 bg-purple-100 rounded-lg"><div className="text-2xl font-bold text-purple-600">89</div><div className="text-sm text-slate-500">Active Wallets</div></div>
          <div className="text-center p-5 bg-amber-100 rounded-lg"><div className="text-2xl font-bold text-amber-600">$2.4M</div><div className="text-sm text-slate-500">Total Value</div></div>
        </div>
      </Card>
    </div>
);

const NetworkSection: React.FC<{metrics: ReturnType<typeof useRealtimeMetrics>}> = ({metrics}) => (
    <Card title="Network Status">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
                <h4 className="font-bold mb-3">Connection Health</h4>
                <div className="space-y-3 text-sm">
                    <div className="flex justify-between"><span>P2P Connections</span><span className="font-bold text-green-600">{metrics.p2pConnections}</span></div>
                    <div className="flex justify-between"><span>Peer Latency</span><span className="font-bold text-blue-600">{metrics.networkLatency.toFixed(0)}ms</span></div>
                    <div className="flex justify-between"><span>Bandwidth Usage</span><span className="font-bold text-purple-600">458 MB/s</span></div>
                    <div className="flex justify-between"><span>Network Uptime</span><span className="font-bold text-green-600">99.9%</span></div>
                </div>
            </div>
             <div>
                <h4 className="font-bold mb-3">Geographic Distribution</h4>
                <div className="space-y-3 text-sm">
                    <div className="flex justify-between"><span>North America</span><span className="font-bold">45%</span></div>
                    <div className="flex justify-between"><span>Europe</span><span className="font-bold">32%</span></div>
                    <div className="flex justify-between"><span>Asia</span><span className="font-bold">18%</span></div>
                    <div className="flex justify-between"><span>Other</span><span className="font-bold">5%</span></div>
                </div>
            </div>
        </div>
    </Card>
);

const AnalyticsSection: React.FC = () => (
    <div>
        <Card title="Performance Analytics">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="p-5 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl">
                    <div className="text-sm text-slate-600 mb-2">Avg Response Time</div>
                    <div className="text-3xl font-bold text-blue-600">45ms</div>
                    <div className="text-xs text-green-600 mt-1">↓ 12% from last week</div>
                </div>
                <div className="p-5 bg-gradient-to-br from-green-100 to-green-200 rounded-xl">
                    <div className="text-sm text-slate-600 mb-2">Success Rate</div>
                    <div className="text-3xl font-bold text-green-600">99.97%</div>
                    <div className="text-xs text-green-600 mt-1">↑ 0.02% improvement</div>
                </div>
                <div className="p-5 bg-gradient-to-br from-purple-100 to-purple-200 rounded-xl">
                    <div className="text-sm text-slate-600 mb-2">System Efficiency</div>
                    <div className="text-3xl font-bold text-purple-600">95%</div>
                    <div className="text-xs text-green-600 mt-1">Optimal performance</div>
                </div>
            </div>
        </Card>
        <Card title="Transaction Analytics">
            <div className="space-y-2">
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg"><span>Daily Volume</span><span className="text-lg font-bold text-blue-600">$847K</span></div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg"><span>Peak TPS</span><span className="text-lg font-bold text-green-600">2,847</span></div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg"><span>Gas Optimization</span><span className="text-lg font-bold text-purple-600">34% Saved</span></div>
            </div>
        </Card>
    </div>
);

export default ManagerPage;
