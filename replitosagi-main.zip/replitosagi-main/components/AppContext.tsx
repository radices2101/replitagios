import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';
import type { Wallet, Transfer, Notification, NotificationType, SecurityEvent, WalletType, Currency, TransferType } from '../types';
import { LOCKED_ENTITIES as initialLockedEntities, CURRENCY_RATES as appCurrencyRates } from '../constants';

// --- INITIAL DATA ---
const initialWallets: Wallet[] = [
    { id: 1, name: 'Main Wallet', address: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb9', type: 'ETH', balance: 15.4582, usdValue: 48234.56, privateKey: 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6', createdAt: '2025-01-15', visible: false },
    { id: 2, name: 'Trading Wallet', address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', type: 'BTC', balance: 0.8432, usdValue: 78456.32, privateKey: 'b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a1', createdAt: '2025-02-20', visible: false },
    { id: 3, name: 'BSC Vault', address: '0x8B3d3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f3f', type: 'BSC', balance: 120.75, usdValue: 37432.50, privateKey: 'c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6a1b2', createdAt: '2025-03-10', visible: false }
];

const initialTransfers: Transfer[] = [
    { id: 1, type: 'crypto', from: '0x742d…bEb9', to: '0x8e23…4f2a', amount: 2.5, currency: 'ETH', usdValue: 7825.50, status: 'completed', timestamp: new Date(Date.now() - 86400000).toISOString(), txHash: '0x9f3e9c3b9c3b9c3b9c3b9c3b9c3b9c3b9c3b9c3b9c3b9c3b9c3b9c3b9c3b7c2d', memo: 'Payment for services' },
    { id: 2, type: 'bank', from: 'Main Wallet', to: 'Bank Account ****4521', amount: 5000, currency: 'USD', usdValue: 5000, status: 'pending', timestamp: new Date(Date.now() - 3600000).toISOString(), txHash: 'TRX-2025-45821', memo: 'Withdrawal to savings' },
    { id: 3, type: 'crypto', from: '1A1zP…fNa', to: '1BvBM…v8s7', amount: 0.1, currency: 'BTC', usdValue: 9300.00, status: 'completed', timestamp: new Date(Date.now() - 172800000).toISOString(), txHash: '0x4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a4f2a', memo: '' }
];

const initialSecurityLog: SecurityEvent[] = [
    { id: 1, timestamp: new Date().toLocaleTimeString(), event: 'SYSTEM_SEALED', target: 'SSH+UFW+IPTABLES', status: 'success' },
    { id: 2, timestamp: new Date().toLocaleTimeString(), event: 'INTENT_ALLOWED', target: 'peace', status: 'success' },
    { id: 3, timestamp: new Date().toLocaleTimeString(), event: 'INTENT_DENIED', target: 'harm', status: 'failure' }
];

// --- CONTEXT TYPES ---
interface DataContextType {
    wallets: Wallet[];
    setWallets: React.Dispatch<React.SetStateAction<Wallet[]>>;
    transferHistory: Transfer[];
    addTransfer: (fromAddress: string, to: string, amountStr: string, currency: Currency, memo: string, type: TransferType) => boolean | string;
    addWallet: (name: string, type: WalletType) => void;
    toggleWalletVisibility: (id: number) => void;
    securityLog: SecurityEvent[];
    addSecurityLog: (event: string, target: string, status: 'success' | 'failure' | 'info') => void;
    lockedEntities: string[];
    addLockedEntity: (entity: string, source?: string) => void;
    prefill: { address: string; currency: WalletType } | null;
    setPrefill: React.Dispatch<React.SetStateAction<{ address: string; currency: WalletType } | null>>;
    CURRENCY_RATES: typeof appCurrencyRates;
}

interface NotificationContextType {
    notifications: Notification[];
    addNotification: (message: string, type: NotificationType) => void;
    removeNotification: (id: number) => void;
}

// --- CONTEXT CREATION ---
const DataContext = createContext<DataContextType | undefined>(undefined);
const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

// --- PROVIDER COMPONENT ---
export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // Data State
    const [wallets, setWallets] = useState<Wallet[]>(initialWallets);
    const [transferHistory, setTransferHistory] = useState<Transfer[]>(initialTransfers);
    const [securityLog, setSecurityLog] = useState<SecurityEvent[]>(initialSecurityLog);
    const [lockedEntities, setLockedEntities] = useState<string[]>(initialLockedEntities);
    const [prefill, setPrefill] = useState<{ address: string; currency: WalletType } | null>(null);

    // Notification State
    const [notifications, setNotifications] = useState<Notification[]>([]);

    const addSecurityLog = useCallback((event: string, target: string, status: 'success' | 'failure' | 'info') => {
        setSecurityLog(prev => [{ id: Date.now(), timestamp: new Date().toLocaleTimeString(), event, target, status }, ...prev]);
    }, []);
    
    const addLockedEntity = useCallback((entity: string, source: string = 'MANAGER_UI') => {
        if (!lockedEntities.includes(entity)) {
            setLockedEntities(prev => [entity, ...prev]);
            addSecurityLog('SYMBOLIC_LOCK', entity, 'success');
        }
    }, [lockedEntities, addSecurityLog]);

    const addWallet = useCallback((name: string, type: WalletType) => {
        const types = {
            'ETH': { prefix: '0x', length: 40 }, 'BTC': { prefix: '1', length: 33 },
            'BSC': { prefix: '0x', length: 40 }, 'MATIC': { prefix: '0x', length: 40 }
        };
        const chars = '0123456789abcdefABCDEF';
        const config = types[type];
        let address = config.prefix + Array.from({ length: config.length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
        const privateKey = Array.from({ length: 64 }, () => chars[Math.floor(Math.random() * 16)]).join('');
        const newWallet: Wallet = {
            id: Date.now(), name, address, type, balance: 0, usdValue: 0, privateKey,
            createdAt: new Date().toISOString().split('T')[0], visible: false
        };
        setWallets(prev => [...prev, newWallet]);
    }, []);
    
    const toggleWalletVisibility = useCallback((id: number) => {
        setWallets(prev => prev.map(w => w.id === id ? { ...w, visible: !w.visible } : w));
    }, []);
    
    const addTransfer = useCallback((fromAddress: string, to: string, amountStr: string, currency: Currency, memo: string, type: TransferType): boolean | string => {
        if (!fromAddress || !to || !amountStr) return "Please fill in all required fields";
        const amount = parseFloat(amountStr);
        const fromWallet = wallets.find(w => w.address === fromAddress);
        if (!fromWallet) return "Source wallet not found";
        if (type === 'crypto' && amount > fromWallet.balance) return "Insufficient balance";

        const txHash = type === 'crypto'
            ? '0x' + Array.from({ length: 64 }, () => '0123456789abcdef'[Math.floor(Math.random() * 16)]).join('')
            : 'TRX-' + new Date().getFullYear() + '-' + Math.floor(Math.random() * 99999);
        const newTransfer: Transfer = {
            id: Date.now(), type, from: fromWallet.address.slice(0, 6) + '...' + fromWallet.address.slice(-4),
            to: to.length > 20 ? to.slice(0, 6) + '...' + to.slice(-4) : to, amount, currency,
            usdValue: amount * (appCurrencyRates[currency] || 0), status: 'pending',
            timestamp: new Date().toISOString(), txHash, memo
        };
        setTransferHistory(prev => [newTransfer, ...prev]);

        if (type === 'crypto') {
            setWallets(prev => prev.map(w => {
                if (w.address === fromAddress) {
                    const newBalance = w.balance - amount;
                    return { ...w, balance: newBalance, usdValue: newBalance * (appCurrencyRates[w.type] || 0) };
                }
                return w;
            }));
        }
        return true;
    }, [wallets]);


    const addNotification = useCallback((message: string, type: NotificationType) => {
        setNotifications(prev => [...prev, { id: Date.now(), message, type }]);
    }, []);

    const removeNotification = useCallback((id: number) => {
        setNotifications(prev => prev.filter(n => n.id !== id));
    }, []);

    return (
        <DataContext.Provider value={{ wallets, setWallets, transferHistory, addTransfer, addWallet, toggleWalletVisibility, securityLog, addSecurityLog, lockedEntities, addLockedEntity, prefill, setPrefill, CURRENCY_RATES: appCurrencyRates }}>
            <NotificationContext.Provider value={{ notifications, addNotification, removeNotification }}>
                {children}
            </NotificationContext.Provider>
        </DataContext.Provider>
    );
};

// --- CUSTOM HOOKS ---
export const useData = (): DataContextType => {
    const context = useContext(DataContext);
    if (!context) throw new Error('useData must be used within an AppProvider');
    return context;
};

export const useNotifications = (): NotificationContextType => {
    const context = useContext(NotificationContext);
    if (!context) throw new Error('useNotifications must be used within an AppProvider');
    return context;
};
