export type WalletType = 'ETH' | 'BTC' | 'BSC' | 'MATIC';
export type TransferStatus = 'completed' | 'pending' | 'failed';
export type TransferType = 'crypto' | 'bank';
export type Currency = 'ETH' | 'BTC' | 'BSC' | 'MATIC' | 'USD' | 'EUR' | 'GBP';

export interface Wallet {
  id: number;
  name: string;
  address: string;
  type: WalletType;
  balance: number;
  usdValue: number;
  privateKey: string;
  createdAt: string;
  visible: boolean;
}

export interface Transfer {
  id: number;
  type: TransferType;
  from: string;
  to: string;
  amount: number;
  currency: string;
  usdValue: number;
  status: TransferStatus;
  timestamp: string;
  txHash: string;
  memo: string;
}

export type NotificationType = 'success' | 'error' | 'info' | 'warning';

export interface Notification {
  id: number;
  message: string;
  type: NotificationType;
}

export interface SecurityEvent {
  id: number;
  timestamp: string;
  event: string;
  target: string;
  status: 'success' | 'failure' | 'info';
}
