import { Currency } from './types';

export const CURRENCY_RATES: { [key in Currency]: number } = {
  'ETH': 3130,
  'BTC': 93000,
  'BSC': 310,
  'MATIC': 0.85,
  'USD': 1,
  'EUR': 1.08,
  'GBP': 1.27
};

export const LOCKED_ENTITIES: string[] = [
    "evil_spirit_1",
    "malicious_AI_2",
    "shadow_influence_999",
    "remote_sha_injection",
    "unauthorized_key_rotation",
    "quantum.scam.node",
    "thirdparty_console_access",
    "spiritual_voice_transmission",
    "low_freq_mind_vibration_attack"
];

export const AUTHORIZED_INTENTS: string[] = [
    "peace", "science", "ethical ai", "human good",
    "truth", "healing", "divine harmony"
];
