
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import ManagerPage from './components/ManagerPage';
import AgiOsPage from './components/AgiOsPage';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<ManagerPage />} />
        <Route path="/os" element={<AgiOsPage />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
