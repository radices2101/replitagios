
import { useState, useEffect } from 'react';

export interface RealtimeData {
  cpuUsage: number;
  memoryUsage: number;
  networkLatency: number;
  activeNodes: number;
  p2pConnections: number;
}

const initialState: RealtimeData = {
  cpuUsage: 45,
  memoryUsage: 62,
  networkLatency: 23,
  activeNodes: 47,
  p2pConnections: 156,
};

export const useRealtimeMetrics = () => {
  const [data, setData] = useState<RealtimeData>(initialState);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setData(prevData => ({
        cpuUsage: Math.max(20, Math.min(80, prevData.cpuUsage + (Math.random() - 0.5) * 10)),
        memoryUsage: Math.max(40, Math.min(85, prevData.memoryUsage + (Math.random() - 0.5) * 8)),
        networkLatency: Math.max(10, Math.min(50, prevData.networkLatency + (Math.random() - 0.5) * 5)),
        activeNodes: Math.max(30, Math.min(60, prevData.activeNodes + Math.floor((Math.random() - 0.5) * 5))),
        p2pConnections: Math.max(100, Math.min(200, prevData.p2pConnections + Math.floor((Math.random() - 0.5) * 20))),
      }));
    }, 2000);

    return () => clearInterval(intervalId);
  }, []);

  return data;
};
