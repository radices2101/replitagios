
import { Currency } from './types';

export const CURRENCY_RATES: { [key in Currency]: number } = {
  'ETH': 3130,
  'BTC': 93000,
  'BSC': 310,
  'MATIC': 0.85,
  'USD': 1,
  'EUR': 1.08,
  'GBP': 1.27
};
